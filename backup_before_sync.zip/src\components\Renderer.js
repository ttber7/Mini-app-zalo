import {
    renderHeroHeader,
    renderStatsGrid,
    renderEmergencyList,
    renderGridMenu,
    renderBottomNav,
    renderOfficialChannel,
    renderLatestNews
} from './StaticComponents.js';
import { renderDynamicForm } from './DynamicForm.js';

/**
 * SDUI Renderer - Đọc JSON và sinh ra Component chuẩn Premium
 */
export function renderSDUI(layoutConfig, container, globalConfig = {}) {
    container.innerHTML = ''; // Clear skeleton

    if (!Array.isArray(layoutConfig)) {
        console.error('[SDUI] Layout config must be an array');
        return;
    }

    layoutConfig.forEach(node => {
        let element = null;
        const type = node._type || node.type;
        const content = node.content || node;

        switch (type) {
            case 'hero_header':
            case 'banner':
                break;
            case 'statistics_grid':
                element = renderStatsGrid(content);
                break;
            case 'official_channel':
                element = renderOfficialChannel(content);
                break;
            case 'latest_news':
            case 'article_list':
                element = renderLatestNews(content);
                break;
            case 'emergency_list':
                element = renderEmergencyList(content);
                break;
            case 'grid_menu':
                element = renderGridMenu(content);
                break;
            case 'form':
                element = renderDynamicForm(content);
                break;
            default:
                console.warn('[SDUI] Component type chưa được hỗ trợ hoặc sai tên:', type);
        }

        if (element) {
            if (node.id) element.id = `sdui-comp-${node.id}`;
            container.appendChild(element);
        }
    });

    // Luôn luôn render Bottom Nav
    const existingNav = document.getElementById('bottom-nav');
    if (existingNav) existingNav.remove();

    // Có thể truyền globalConfig vào BottomNav nếu muốn đổi màu icon theo màu chủ đạo
    const bottomNav = renderBottomNav(globalConfig);
    bottomNav.id = 'bottom-nav';
    document.body.appendChild(bottomNav);
}
